from distkit.gaussian import Gaussian
from distkit.binomial import Binomial