# distkit
 A simple package to generate statistical distributions
 GitHub - https://github.com/abhinav314/distkit
