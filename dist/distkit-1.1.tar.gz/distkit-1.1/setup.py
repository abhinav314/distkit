from setuptools import setup

setup(name='distkit',
      version='1.1',
      description='Gaussian and Binomial distributions',
      packages=['distkit'],
      author='Abhinav Chanda',
      author_email='abhinav468@gmail.com',
      zip_safe=False)
