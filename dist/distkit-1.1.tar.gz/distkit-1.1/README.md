# distkit
 Package to generate statistical distributions
